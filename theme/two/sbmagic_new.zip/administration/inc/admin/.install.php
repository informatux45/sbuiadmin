<?php
/**
 * Admin Startbootstrap
 * SBUIADMIN INSTALLER
 *
 * @link http://dev.informatux.com/
 *
 * @package SBUIADMIN
 * @file UTF-8
 * ©INFORMATUX.COM
 */

header("Status: 301 Moved Permanently", false, 301);
header("Location: ./install/install.php");
exit();
?> 