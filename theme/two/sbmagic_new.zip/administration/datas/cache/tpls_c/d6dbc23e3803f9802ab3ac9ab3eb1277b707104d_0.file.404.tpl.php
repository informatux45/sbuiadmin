<?php
/* Smarty version 3.1.29, created on 2016-11-29 10:12:17
  from "/Applications/MAMP/htdocs/sbmagic_new/administration/core/tpls/tpl/404.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_583d4671dc2e76_01009116',
  'file_dependency' => 
  array (
    'd6dbc23e3803f9802ab3ac9ab3eb1277b707104d' => 
    array (
      0 => '/Applications/MAMP/htdocs/sbmagic_new/administration/core/tpls/tpl/404.tpl',
      1 => 1479215896,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_583d4671dc2e76_01009116 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="fr">
	<head>
		<!-- Custom Admin CSS -->
		<link href="assets/dist/css/sb-admin-custom.css" rel="stylesheet">
	</head>
	<body style="background: white url(<?php echo @constant('_AM_SITE_IMG_URL');?>
unavailable-module.jpg) no-repeat center center fixed; background-size: cover;"></body>
</html><?php }
}
