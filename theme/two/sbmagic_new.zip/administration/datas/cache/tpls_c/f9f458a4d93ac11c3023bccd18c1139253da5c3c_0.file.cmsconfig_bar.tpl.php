<?php
/* Smarty version 3.1.29, created on 2016-12-20 14:40:55
  from "/Applications/MAMP/htdocs/sbmagic_new/administration/core/tpls/tpl/system/cmsconfig_bar.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_585934e7ba3a76_08498839',
  'file_dependency' => 
  array (
    'f9f458a4d93ac11c3023bccd18c1139253da5c3c' => 
    array (
      0 => '/Applications/MAMP/htdocs/sbmagic_new/administration/core/tpls/tpl/system/cmsconfig_bar.tpl',
      1 => 1476432499,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_585934e7ba3a76_08498839 ($_smarty_tpl) {
?>


<div class="well well-sm">
	

		<button class="btn btn-outline btn-danger" type="button" onclick="location.href='index.php?p=cmsconfig&op=headerfooter'">
			Header / Footer
		</button>
		&nbsp;
		<button class="btn btn-outline btn-danger" type="button" onclick="location.href='index.php?p=cmsconfig&op=css'">
			CSS Header
		</button>
		&nbsp;
		<button class="btn btn-outline btn-danger" type="button" onclick="location.href='index.php?p=cmsconfig&op=javascript'">
			JAVASCRIPT Code
		</button>
		&nbsp;
		<button class="btn btn-outline btn-danger" type="button" onclick="location.href='index.php?p=cmsconfig&op=email'">
			EMAIL config
		</button>
		&nbsp;
		<button class="btn btn-outline btn-danger" type="button" onclick="location.href='index.php?p=cmsconfig&op=comingsoon'">
			Coming Soon
		</button>
		&nbsp;
		<button class="btn btn-outline btn-danger" type="button" onclick="location.href='index.php?p=cmsconfig&op=multilang'">
			Multilangue
		</button>
		&nbsp;
		<button class="btn btn-outline btn-danger" type="button" onclick="location.href='index.php?p=cmsconfig&op=plugins'">
			Plugins
		</button>
		&nbsp;
		<button class="btn btn-outline btn-danger" type="button" onclick="location.href='index.php?p=cmsconfig&op=fonts'">
			Fonts
		</button>
		&nbsp;
		<button class="btn btn-outline btn-danger" type="button" onclick="location.href='index.php?p=cmsconfig&op=seo'">
			SEO
		</button>
		
</div><?php }
}
