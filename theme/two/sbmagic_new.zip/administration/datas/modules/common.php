<?php
/**
 * Admin Startbootstrap
 * Common Infos Admin Modules (Developers)
 *
 * @link http://dev.informatux.com/
 *
 * @package SBUIADMIN
 * @file UTF-8
 * ©INFORMATUX.COM
 */

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// Blocking direct access to plugin      -=
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
defined('SBMAGIC_PATH') or die('Are you crazy!');

// -----------------------
// Menu Module SAMPLE
// -----------------------
//$module_menu['slider']['main']  = "Sliders";
//$module_menu['slider']['icon']  = "sliders";
//$module_menu['slider']['group'] = "user"; // user OR admin
// ---------------
//$module_menu['slider']['li'][0]['title'] = "Tous les sliders";
//$module_menu['slider']['li'][0]['link']  = "index.php?p=slider";
// ---------------
//$module_menu['slider']['li'][1]['title'] = "Ajouter un slider";
//$module_menu['slider']['li'][1]['link']  = "index.php?p=slider&a=add";
// ---------------
//$module_menu['slider']['li'][2]['title'] = "Ajouter une photo / vidéo";
//$module_menu['slider']['li'][2]['link']  = "index.php?p=slider&a=photoadd";

// ---------------------------------------------------------------------
// ---------------------------------------------------------------------
// ---------------------------------------------------------------------
// Put your code after these lines
// ---------------------------------------------------------------------
// ---------------------------------------------------------------------
// ---------------------------------------------------------------------


?>